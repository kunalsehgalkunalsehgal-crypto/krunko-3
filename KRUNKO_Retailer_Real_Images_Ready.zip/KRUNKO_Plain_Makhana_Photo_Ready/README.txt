KRUNKO RETAILER WEBSITE - REAL PHOTO READY (V3)
================================================

WHAT THIS VERSION DOES
- Keeps the existing KRUNKO retailer page design and enquiry form.
- Focuses only on plain makhana, NOT flavoured snack packs or jars.
- Gives you 3 ready-to-use places for REAL photos.
- When a photo is not yet added, the original illustrated design shows.
- Desktop, tablet and mobile layouts use responsive CSS.
- Your original customer site is NOT included or changed.

ADD YOUR REAL PHOTOS IN 3 SIMPLE STEPS

1) Open the 'images' folder inside this download.
2) Put YOUR actual photos there, using these exact file names:

   hero-makhana.jpg       -> Large image in top banner
   processing-machine.jpg -> Real factory/machine photo in Our Process
   plain-makhana.jpg      -> Real plain makhana photo in Product section

3) Open 'retailer.html' in the browser. That's it!

You do NOT have to write code or change HTML if the files are JPG
with exactly those names. The old illustrations automatically disappear
only where a valid image was found. If a photo is missing, nothing breaks.

IMPORTANT: If your photos are .png / .webp instead of .jpg:
- Use a photo editor to EXPORT as JPG (don't only rename the extension), OR
- Open 'retailer.html' and replace the relevant image src extension.
  Search 'images/hero-makhana.jpg' etc and enter your real filename.

PHOTO SIZE TIPS (FOR A CLEAN, QUICK WEBSITE)
- Hero:       square / near-square photo. Aim for 1200 x 1200 pixels.
- Process:    square / landscape photo. Aim for at least 1200 x 1000.
- Product:    square / portrait photo. Aim for 1200 x 1200.
- JPG quality around 75-85% usually looks good and keeps it small.
- Try to keep each optimized image below ~400 KB if possible.
- Take photos with the important subject in the middle so mobile
  cropping does not cut it off.

TO CHANGE HOW YOUR PHOTO IS CROPPED
Open 'retailer.css', find 'REAL PHOTO SLOTS (V3)' near the bottom.
Under .real-photo--hero / --process / --product, you can change:

  object-position: center center;

Examples:  center 25% (show more of the top), center 70% (show more of bottom).
Avoid changing width/height unless you need a new layout.

HOW TO OPEN / TEST
1) Keep choose.html, retailer.html, retailer.css, retailer.js,
   assets/ and images/ together in one folder.
2) Open retailer.html in Chrome; resize to see mobile layout.
3) Open choose.html to check Customer / Retailer selection.
4) Customer button in choose.html currently links to index (3).html.
   Point it to your actual customer homepage route before publishing.

FORM - VERY IMPORTANT
- It creates an email draft, not an automatic order/enquiry submission.
- Buyer MUST send the email manually from their email app.
- It does NOT save customer data or connect to a Laravel backend.
- Verify the destination email before launch.
- A real Laravel form endpoint is needed for automatic lead collection.

FACTS TO CONFIRM BEFORE LAUNCH
- Use a real machine/process photo from your OWN actual operation.
- Confirm any manufacturing or hygiene text with your team.
- Confirm product size, quality, supply, price and dispatch details.
- Replace any draft content that does not describe your real operations.
- Do not show photos that imply a machine/process you don't use.

HAVE FUN BUILDING KRUNKO!
