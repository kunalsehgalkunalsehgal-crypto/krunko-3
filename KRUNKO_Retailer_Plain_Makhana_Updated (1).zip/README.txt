KRUNKO: RETAILER LANDING PAGE + CUSTOMER / RETAILER CHOICE
=========================================================

FILES
- choose.html: two-choice entry page (Customer / Retailer)
- retailer.html: retailer landing page, machine-process story, five flavours, and retailer form
- retailer.css: responsive design for both new pages
- retailer.js: mobile menu, flavour choice handling, form validation, email draft
- assets/krunko-logo.png: the exact KRUNKO logo you supplied

QUICK PREVIEW
Open choose.html in a browser, then click "I'm a Retailer".
The retailer page can also open directly using retailer.html.

CUSTOMER PATH
In choose.html, the Customer card links to "index (3).html", the exact name
of the existing HTML file you uploaded. Put choose.html and retailer.html in
the SAME FOLDER as your existing customer page, or update that one link to
your deployed customer homepage path (for example /shop or /customer).
The new pages DO NOT overwrite your existing index (3).html, style.css,
or script.js.

MAKING CHOOSE.HTML APPEAR FIRST
You must make the web server's entry route load choose.html, or redirect your
homepage URL to that page. Simply uploading choose.html will NOT change the
site's default landing page. Do not rename or overwrite the existing index
until you have tested routing / backups.

REAL PRODUCT PHOTOS
retailer.html refers to the existing product photos from your supplied site:
assets/jar-peri.webp, assets/himaliyan salt.webp, assets/jar-tomato.webp,
assets/gud til.webp, assets/jar-cheese.webp.
These photos were NOT in your upload. The retailer design displays styled
fallback product artwork until you place those original assets at these paths.
The jar display in the hero and the production machine diagram are DESIGN
ILLUSTRATIONS, not official product packaging or the actual factory machine.
Replace them with verified images if you have them.

IMPORTANT: THE FORM IS A DESIGN PREVIEW
On successful validation, the form prepares a draft in the visitor's email
app, addressed to info@thefarmproject.co.in (from your existing website).
The visitor must click "Open email draft" and then press Send in their email
app. It does NOT send email automatically. This preview does not save form
data, create a database row, or post to any third-party service.
A "Copy enquiry details" fallback is included.

For automatic submission, link the form to a Laravel route/API or a verified
email provider, then add spam checks, server validation, secure storage, and
a privacy notice. Before launch confirm that info@thefarmproject.co.in is
the right business enquiry address.

BEFORE YOU PUBLISH
1. Confirm your factory story and hygiene wording with your production team.
2. Add real machine / plant photos and true product jar photos.
3. Confirm the five flavours and which formats/pack sizes retailers can buy.
4. Connect a real enquiry backend and set who receives leads.
5. Review privacy/consent copy, business email, and routing.
6. Test on real phones; validate SMS/WhatsApp calling country support if needed.

FORM FIELDS
Required: full name; mobile/WhatsApp; store/business name; business type;
city; state/UT; PIN code; consent to be contacted.
Fixed enquiry product: Plain Makhana (no flavour selection).
Optional: shop address / market area; GSTIN; expected order size; preferred contact method; business email;
questions/message.

No changes were made to your original customer files.
